const jwt = require('jsonwebtoken');
const User = require('../model/userModel');

// General authentication middleware for all users
const authenticate = async (req, res, next) => {
  const token = req.headers.authorization?.split(" ")[1];
  if (!token) return res.status(401).json({ message: "Unauthorized" });

  try {
    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    const user = await User.findById(decoded.id);

    if (!user) {
      return res.status(404).json({ message: "User not found" });
    }

    req.user = user; // attach full user object
    next();
  } catch (err) {
    res.status(401).json({ message: "Invalid token" });
  }
};

// Seller-specific authentication middleware
const authenticateSeller = async (req, res, next) => {
  const token = req.headers.authorization?.split(" ")[1];
  if (!token) return res.status(401).json({ message: "Unauthorized" });

  try {
    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    const user = await User.findById(decoded.id);

    if (!user) {
      return res.status(404).json({ message: "User not found" });
    }

    if (user.role !== 'seller') {
      return res.status(403).json({ message: "Access denied. Seller role required." });
    }

    req.user = user; // attach full user object
    next();
  } catch (err) {
    res.status(401).json({ message: "Invalid token" });
  }
};

module.exports = { authenticate, authenticateSeller };
