const userController = require('../controllers/userController');
const { authenticate } = require('../middleware/authMiddleware');
const express = require('express');
const router = express.Router();    

router.post('/signup', userController.signup);
router.post('/login', userController.login);
router.post('/google', userController.googleAuth);
router.put('/update-profile', authenticate, userController.updateProfile);
router.get('/me', authenticate, userController.getMe);
router.post('/address', authenticate, userController.saveAddress);

module.exports = router;